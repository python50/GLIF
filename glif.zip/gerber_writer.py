#------------------------------------------------------------------------------
# Gerber Writer - A Wrapper for Gerber Writer Core
#------------------------------------------------------------------------------
#
# Author: Jason White
# Licence: GPLv2
#
# a high-ish level gerber RS274X writer
# Takes in the 5 graphical primitives and
# outputs a gerber file in MM mode
# with positive polarity
#
# all coodinates expected to be integer and in micrometers (6 zeros, 1mm=1000000um)
# but thickness and is expected in milimeters, floating point
#
# check out test_gerber_writer() for an example of how to make it work
#

from math import radians, sin, cos

import types
from symbols import *
import group
from primitives import *

from gerber_writer_core import *

class gerber_writer:
	def __init__(self, filename):
		self.filename=filename
		self.f=open(filename, "w")
		self.apertures=[]
		self.primitives=[]
	
	def write(self):
		write_start(self.f)
		
		self.define_apertures()
		
		write_apertures(self.f, self.apertures)
		
		self.write_primitives()
		
		write_end(self.f)
		
	def write_primitives(self):
		for i, p in enumerate(self.primitives):
			self.write_primitive(i, p)
	
	def write_primitive(self, i, p):
		if isinstance(p,line):
			write_line(self.f, p.aperture, [p.start.x, p.start.y], [p.end.x, p.end.y])
		elif isinstance(p,arc):
			print("Error: Arcs unsuppored, need a function to convert an arc into line segments")
		elif isinstance(p,circle):
			write_line(self.f, p.aperture, [p.location.x, p.location.y], [p.location.x, p.location.y])
		elif isinstance(p,text):
			self.write_text(p)
		elif isinstance(p,polygon):
			write_polygon(self.f, p.location.x, p.location.y, p.points)
		else:
			print("Error unsupported primitive %s" % p)
	
	def rotate_point(self, point, angle, offset=(0.0, 0.0)):
	    angle = radians(angle)
	    
	    delta_x = point[0]
	    delta_y = point[1]
	    
	    x = offset[0] + (cos(angle) * delta_x) - (sin(angle) * delta_y)
	    y = offset[1] + (sin(angle) * delta_x) + (cos(angle) * delta_y)
	    return (x, y)
		
	def write_text(self, p):
		offset=0
		center=(p.location.x,p.location.y)
		
		for char in p.text:
					
			for i in SYMBOLS[char].elements:
				
				start_point=(offset+i.x1, i.y1)
				end_point=(offset+i.x2, i.y2)
				
				start_location=self.rotate_point(start_point, p.angle, center)
				end_location=self.rotate_point(end_point, p.angle, center)
				
				write_line(self.f, p.aperture, start_location, end_location)
					
			offset+=SYMBOLS[char].size
			
	def define_apertures(self):
		for i, p in enumerate(self.primitives):
			self.define_aperture(i, p)
				
	def define_aperture(self, i, p):
		#All other types (line, arc, circle, text) use custom width apertures
		if isinstance(p, polygon):
			return
			
		
		a=aperture("C", p.design_rules.thickness)
		if isinstance(p, line):
			a.type=p.shape
		
		p.aperture=self.check_duplicate(a)
		
		if type(p.aperture)!=int:
			p.aperture=len(self.apertures)
			self.apertures.append(a)
			
		
		
	def check_duplicate(self, aperture):
		for i, a in enumerate(self.apertures):
		
			if a.type==aperture.type and a.size==aperture.size:
				return i
		return False
		

def test_gerber_writer():	
	writer=gerber_writer("export2.gbr")
	
	writer.primitives=[
		line(1000000, 1000000, 2000000, 2000000, "C", 0, "", thickness=0.25, clearance=None),
		line(1000000, 2000000, 2000000, 3000000, "R", 0, "", thickness=0.5, clearance=None),
		line(1000000, 3500000, 2000000, 3500000, "C", 0, "", thickness=0.25, clearance=None),
	
		line(1000000, 4000000, 2000000, 4000000, "R", 0, "", thickness=0.25, clearance=None),
		line(2500000, 1000000, 2500000, 1000000, "R", 0, "", thickness=1, clearance=None),
	
		circle(0000000, 0000000, 1, 0, "", thickness=0.5, clearance=None),
		circle(0000000, 2000000, 1, 0, "", thickness=0.5, clearance=None),
		circle(3500000, 3000000, 1, 0, "", thickness=1.25, clearance=None),
	
	
		polygon(1000000, 0, 1, [[3000000,0],[4000000,0],[4000000,1500000],  [2500000,1500000], [3000000,1000000]], 0, "", thickness=0.0, clearance=None),
		text(0, -1500000, "Hello!", 1, 0, 0, "", thickness=0.15, clearance=None),
	
		text(-5000000, 000000, "Any Angle Text", 0.25, 45, 0, "", thickness=0.04, clearance=None)
		]
	
	writer.write()


test_gerber_writer()
